import { AddVideo } from "./_components/add-video";

export default function Home() {
  return (
    <div className=" h-screen w-screen flex flex-col items-center">
      <AddVideo />
    </div>
  );
}
